<?php
    function my_setup() {
        // enabale post thumbnail and feature images.
        add_theme_support('post-thumbnails');

        load_theme_textdomain('customtheme', get_template_directory() . '/languages');

        register_nav_menus( array(
            'primary_menu' => __( 'Primary Menu', 'customtheme' ),
            'footer_menu'  => __( 'Footer Menu', 'customtheme' ),
        ) );
    }
    add_action('after_setup_theme', 'my_setup');

    // register_nav_menus( string[] $locations = array() )

    function sliders_setup_post_type() {
        $args = array(
            'public'    => true,
            'label'     => __( 'sliders', 'customtheme' ),
            'menu_icon' => 'dashicons-images-alt',
            'supports' => array('title', 'author', 'thumbnail')
            // 'editor', 'excerpt', 'comments'
        );
        register_post_type( 'sliders', $args );
    }
    add_action( 'init', 'sliders_setup_post_type' );



    // dynamic services in home page
    function services_setup_post_type() {
        $args = array(
            'public'    => true,
            'label'     => __( 'services', 'customtheme' ),
            'menu_icon' => 'dashicons-admin-network',
            'supports' => array('title', 'editor', 'thumbnail', 'comments')
            // 'editor', 'author', 'comments'
        );
        register_post_type( 'services', $args );
    }
    add_action( 'init', 'services_setup_post_type' );

    /* Disable Widgets Block Editor */
    add_filter( 'use_widgets_block_editor', '__return_false' );

    function all_widgets_init() {
        register_sidebar( array(
            'name'          => __( 'Main Sidebar', 'customtheme' ),
            'id'            => 'sidebar-1',
            'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'customtheme' ),

            // optional
            'before_widget' => '<div class="box">',
            'after_widget'  => '</div></div>',
            'before_title'  => '<div class="heading"><h2>',
            'after_title'   => '</h2></div><div class="content">',
        ) );
    }
    add_action( 'widgets_init', 'all_widgets_init' );

// footer widget
    function footer_widgets_init() {
        register_sidebar( array(
            'name'          => __( 'Footer Sidebar', 'customtheme' ),
            'id'            => 'sidebar-3',
            'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'customtheme' ),

            // optional
            'before_widget' => '<div class="col-1-4"><div class="wrap-col"><div class="box">',
            'after_widget'  => '</div></div></div></div>',
            'before_title'  => '<div class="heading"><h2>',
            'after_title'   => '</h2></div><div class="content">',
        ) );
    }
    add_action( 'widgets_init', 'footer_widgets_init' );


    // customize post_excerpt
    function wpdocs_custom_excerpt_length( $length ) {
        return 15;
    }
    // add_filter use modify existing function
    add_filter( 'excerpt_length', 'wpdocs_custom_excerpt_length');
?>