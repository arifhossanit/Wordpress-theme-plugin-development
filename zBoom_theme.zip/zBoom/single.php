<?php get_header(); ?>
<!--------------Content--------------->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block03">
			<div class="col-2-3">
				<div class="wrap-col">
                    <?php
                        if (have_posts()) :
                            while (have_posts()) : the_post();
                    ?>
					<article>
						<!-- <img src="images/img1.png"/> -->
						<h2><a href="#"><?php the_title(); ?></a></h2>
						<div class="info">[ <?php the_time("F d, Y") ?>  by <?php the_author(); ?> | <a href="<?php the_permalink(); ?>"><?php comments_number( 'no responses', '1 comment', '% comments' ); ?></a>]</div>
						<p><?php the_content(); ?></p>
						<div class="comment">
							Your email address will not be published. Required fields are marked *
							<?php comments_template(); ?>
						</div>
					</article>
                    <?php
                            endwhile;
                        else:
                            _e('Sorry no post found', 'textdomain');
                        endif;
                    ?>
				</div>
			</div>
			<?php get_sidebar(); ?>
		</div>
	</div>
</section>


<?php get_footer(); ?>