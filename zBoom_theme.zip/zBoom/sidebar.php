<div class="col-1-3">
				<div class="wrap-col">
					<?php dynamic_sidebar('sidebar-1'); ?>
					<!-- <div class="box">
						
						<div class="heading"><h2>Latest Albums</h2></div>
						<div class="content">
							<img src="/images/albums.png"/>
						</div>
					</div> -->
					<!-- <div class="box">
						<div class="heading"><h2>Upcoming Events</h2></div>
						<div class="content">
							<div class="list">
								<ul>
									<li><a href="#">Magic Island Ibiza</a></li>
									<li><a href="#">Bamboo Is Just For You</a></li>
									<li><a href="#">Every Hot Summer</a></li>
									<li><a href="#">Magic Island Ibiza</a></li>
									<li><a href="#">Bamboo Is Just For You</a></li>
									<li><a href="#">Every Hot Summer</a></li>
								</ul>
							</div>
						</div>
					</div> -->
				</div>
			</div>